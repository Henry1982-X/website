# MMM-physics
This repository contains physics parameterizations shared by MPAS, WRF, and CM1. Modules follow CCPP coding standards.
