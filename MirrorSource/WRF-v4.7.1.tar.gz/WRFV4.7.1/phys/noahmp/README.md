# Noah-MP version 4.7 release


This is the official Noah-MP code version 4.7 consistent with that released in WRF v4.7. Note that WRF v4.7 GitHub code is directly connected to this Noah-MP GitHub through the submodule mechanism. 

