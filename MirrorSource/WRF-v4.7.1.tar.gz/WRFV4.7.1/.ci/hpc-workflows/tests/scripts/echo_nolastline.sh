#!/bin/sh

config=$1
dir=$2
cd $dir

shift; shift
echo $*
